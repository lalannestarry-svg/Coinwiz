
# 🪙 CoinScope
Mobile-friendly coin identifier & appraiser.
- Upload or use camera 📸
- Suggested grade (G → MS) 🏷️
- Appraise with CSV guide 💰
- Export PDF/CSV 📑

## Deploy (free)
Push to GitHub → deploy on Streamlit Community Cloud: https://streamlit.io/cloud
